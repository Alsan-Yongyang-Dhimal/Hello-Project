-- Adminer 4.8.1 MySQL 8.0.31 dump

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `cars` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;

USE `cars`; 

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password` varchar(100) NOT NULL,
  `contactnumber` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `admins` (`id`, `username`, `email`, `password`, `contactnumber`) VALUES
(7,	'user1',	'alsandhimal646@gmail.com',	'password',	'9804049289'),
(8,	'claire',	'ram@gmail.com',	'opensesame',	'9804049289')
ON DUPLICATE KEY UPDATE `id` = VALUES(`id`), `username` = VALUES(`username`), `email` = VALUES(`email`), `password` = VALUES(`password`), `contactnumber` = VALUES(`contactnumber`);

DROP TABLE IF EXISTS `articles`;
CREATE TABLE `articles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `description` longblob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `articles` (`id`, `title`, `description`) VALUES
(2,	'Hello ',	'namastey'),
(5,	'Election Day',	'Let\'s vote a good candidate.'),
(6,	'World Cup starts from today.....',	'let\'s support all the teams.'),
(9,	'Hello ',	'Namastey')
ON DUPLICATE KEY UPDATE `id` = VALUES(`id`), `title` = VALUES(`title`), `description` = VALUES(`description`);

DROP TABLE IF EXISTS `cars`;
CREATE TABLE `cars` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `manufacturerId` int DEFAULT NULL,
  `description` longblob,
  `oldprice` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enginetype` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mileage` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `cars` (`id`, `name`, `price`, `manufacturerId`, `description`, `oldprice`, `enginetype`, `mileage`) VALUES
(1,	'XJS',	'15000',	2,	'Made in 1996, available in green and black.',	NULL,	NULL,	NULL),
(3,	'E-Type',	'30000',	2,	'Excellent condition used E-Type, only 20,000 miles. ',	NULL,	NULL,	NULL),
(4,	'280SL',	'35000',	3,	'Gold, in excellent condition',	NULL,	NULL,	NULL),
(5,	'300SL',	'14000',	3,	'1992 model with just 70,000 miles.',	NULL,	NULL,	NULL),
(6,	'DB4',	'99000',	4,	'Classic DB4. Minor scratches but otherwise flawless condition. ',	NULL,	NULL,	NULL),
(7,	'Honda',	'80',	3,	'ff',	'89',	'p',	'50km/ltr'),
(12,	'i20',	'500000',	5,	'best 2020 car in World.',	'56000',	'petrol',	'35')
ON DUPLICATE KEY UPDATE `id` = VALUES(`id`), `name` = VALUES(`name`), `price` = VALUES(`price`), `manufacturerId` = VALUES(`manufacturerId`), `description` = VALUES(`description`), `oldprice` = VALUES(`oldprice`), `enginetype` = VALUES(`enginetype`), `mileage` = VALUES(`mileage`);

DROP TABLE IF EXISTS `enquiries`;
CREATE TABLE `enquiries` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contactnumber` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `enquiry` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `enquiries` (`id`, `fullname`, `email`, `contactnumber`, `enquiry`) VALUES
(2,	'Alsan Dhimal',	'alsandhimal646@gmail.com',	'9804049289',	'i want to buy a new cars.'),
(4,	'Alsan Dhimal',	'alsandhimal646@gmail.com',	'9804049289',	'fff'),
(5,	'Alishan DHimal',	'alishan@gmail.com',	'9804049289',	'i want to buy new car'),
(6,	'ALishan DHimal',	'alsandhimal646@gmail.com',	'9804049289',	'hello')
ON DUPLICATE KEY UPDATE `id` = VALUES(`id`), `fullname` = VALUES(`fullname`), `email` = VALUES(`email`), `contactnumber` = VALUES(`contactnumber`), `enquiry` = VALUES(`enquiry`);

DROP TABLE IF EXISTS `manufacturers`;
CREATE TABLE `manufacturers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `manufacturers` (`id`, `name`) VALUES
(2,	'Jaguar'),
(3,	'Mercedes'),
(4,	'Aston Martin'),
(7,	'Honda'),
(10,	'BMW')
ON DUPLICATE KEY UPDATE `id` = VALUES(`id`), `name` = VALUES(`name`);

-- 2022-11-20 13:35:52
