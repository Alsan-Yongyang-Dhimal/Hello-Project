<?php
// making the controllersfor all the classes
class controllerAdmin {
	// creating the private variable here
	private $tableAdmin;
    
	// creatig the functiins here 
	public function __construct($tableAdmin) {
		// callling it
		$this->tableAdmin = $tableAdmin;
	}
    //calling the fucntion for all
	public function list() {
    //    calling
		$alsanstmt = $this->tableAdmin->findAll();
        //   it will return all the bvalues here
		return ['template' => 'admintemplate.php', 
				'title' => 'Enquiry List',
				'variables' => [
						'admin' => $alsanstmt
					]
				];
	}
  
	// for the section of the del
	public function delete() {
		// here
		$this->tableAdmin->delete($_POST['id']);

	
	}
//    for the section for the pages
	public function home() {
		// ere
		$alsanstmt = $this->tableAdmin->find('id', 1);
//  all the values it will have
		return [
			'template' => 'home.php',
			'variables' => ['enquiry' => $alsanstmt[0]],
			'title' => 'alsanstmt'
		];

	}
    // this is the section for the crude ops
	public function edit() {
		// calling ths function called isset
		if (isset($_POST['submit'])) {
			//doing the dunction to have it on set
			unset($_POST['submit']);
		    // calling it
			$alsanstmt = $_POST;
			
            //doing the 
			$this->tableAdmin->save($alsanstmt);

			
		}
		else {
			//finding the all the tables here
			if  (isset($_GET['id'])) {
				$result = $this->tableAdmin->find('id', $_GET['id']);
				//values = 0
				$alsanstmt = $result[0];
			}
			else  {
				//doing the 
				$alsanstmt = false;
			}
            // values will be dispplayes
			return [
				'template' => 'admintemplate.php',
				'variables' => ['admin' => $alsanstmt],
				'title' => 'Edit Enquiry'
			];
		}
	}
		
	
		
	}

