<?php
class controllerEnquiry {
	private $alsanenquiry;

	public function __construct($alsanenquiry) {
		$this->alsanenquiry = $alsanenquiry;
	}

	public function list() {

		$alsanstmt = $this->alsanenquiry->findAll();

		return ['template' => 'enquirytemplate.php', 
				'title' => 'Enquiry List',
				'variables' => [
						'enquiry' => $alsanstmt
					]
				];
	}

	public function delete() {
		$this->alsanenquiry->delete($_POST['id']);

	
	}

	public function home() {
		$alsanstmt = $this->alsanenquiry->find('id', 1);

		return [
			'template' => 'home.php',
			'variables' => ['enquiry' => $alsanstmt[0]],
			'title' => 'alsanstmt'
		];

	}

	public function edit() {
		if (isset($_POST['submit'])) {
			unset($_POST['submit']);
			
			$alsanstmt = $_POST;
		

			$this->alsanenquiry->save($alsanstmt);

			
		}
		else {
			if  (isset($_GET['id'])) {
				$result = $this->alsanenquiry->find('id', $_GET['id']);
				$alsanstmt = $result[0];
			}
			else  {
				$alsanstmt = false;
			}

			return [
				'template' => 'enquirytemplate.php',
				'variables' => ['enquiry' => $alsanstmt],
				'title' => 'Edit Enquiry'
			];
		}
	}
}
