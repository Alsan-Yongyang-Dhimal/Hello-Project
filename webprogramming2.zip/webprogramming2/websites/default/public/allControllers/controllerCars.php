<?php
//calling the values
class controllerCars {
	//making the variables
	private $tableCars;
	//here also making
    private $tableManufacturer;
	
	//all the constucting all tha values 
	public function __construct($tableCars,$tableManufacturer) {
		//recommend
		$this->tableCars = $tableCars;
		//recommend
		$this->tableManufacturer = $tableManufacturer;
	}
// for all the listing the
	public function list() {
//finding all the values
		$car = $this->tableCars->findAll();
		// /here also doing the same
		$manufacturer = $this->tableManufacturer->findAll();
//having all it
		return ['template' => 'carstemplate.php', 
				'title' => 'car List',
				'variables' => [
						'car' => $car,
						'manufacturer' => $manufacturer
					]
				];
	}
    // for the deleting here
	public function delete() {
		$this->tableCars->delete($_POST['id']);

		
	}
// all the same as all
	public function home() {
		$car = $this->tableCars->find('id', 1);

		return [
			'template' => 'home.php',
			'variables' => ['car' => $car[0]],
			'title' => 'Car'
		];

	}
//   all the same as all
	public function edit() {
		//finds allthings
		$manufacturer = $this->tableManufacturer->findAll();
		//required elemets
		if (isset($_POST['submit'])) {
			// here
			$car = $_POST;
			// saving the values 
	
			$this->tableCars->save($car);

		
		
	    }
		else 
		// getting the values of car
			if  (isset($_GET['id'])) {
				$result = $this->tableCars->find('id', $_GET['id']);
				$car = $result[0];
			}
		// all the values

			else  {
				$car = false;
			}
    //  saving all it
			return [
				'template' => 'editcarstemplate.php',
				'variables' => ['car' => $car,'manufacturer' => $manufacturer],
				'title' => 'Edit car'
			];
		}
	}

