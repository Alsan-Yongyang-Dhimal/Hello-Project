<?php
// making tha classesssss
class controllerArticle {
	private $tableArticle;
// making the consturctors
	public function __construct($tableArticle) {
		$this->tableArticle = $tableArticle;
	}
//finding all the list here
	public function list() {
// fetching all thedata 
		$alsanstmt = $this->tableArticle->findAll();

		return ['template' => 'articletemplate.php', 
				'title' => 'Enquiry List',
				'variables' => [
						'article' => $alsanstmt
					]
				];
	}
    // for the deleting all the values
	public function delete() {
		$this->tableArticle->delete($_POST['id']);

	
	}
//    for all the page
	public function home() {
		//hello
		$alsanstmt = $this->tableArticle->find('id', 1);

		return [
			'template' => 'home.php',
			'variables' => ['enquiry' => $alsanstmt[0]],
			'title' => 'alsanstmt'
		];

	}

	public function edit() {
		if (isset($_POST['submit'])) {
			unset($_POST['submit']);
			//calling it
			$alsanstmt = $_POST;
		//    for the saving all the data
			$this->tableArticle->save($alsanstmt);

			
		}
		else {
			//for the value getting all it
			if  (isset($_GET['id'])) {
				$result = $this->tableArticle->find('id', $_GET['id']);
				$alsanstmt = $result[0];
			}
			else  {
				$alsanstmt = false;
			}
        //   values will be all
			return [
				'template' => 'articletemplate.php',
				'variables' => ['article' => $alsanstmt],
				'title' => 'Edit Enquiry'
			];
		}
	}
}
