<?php
class controllerManufacturer {
	private $tableManufacturer;

	public function __construct($tableManufacturer) {
		$this->tableManufacturer = $tableManufacturer;
	}

	public function list() {

		$manufacturer = $this->tableManufacturer->findAll();

		return ['template' => 'manufacturertemplate.php', 
				'title' => 'manufacturer List',
				'variables' => [
						'manufacturer' => $manufacturer
					]
				];
	}

	public function delete() {
		$this->tableManufacturer->delete($_POST['id']);

		
	}

	public function home() {
		$manufacturer = $this->tableManufacturer->find('id', 1);

		return [
			'template' => 'home.php',
			'variables' => ['manufacturer' => $manufacturer[0]],
			'title' => 'manufacturer'
		];

	}

	public function edit() {
		if (isset($_POST['submit'])) {
			
			$manufacturer = $_POST;
			
			$this->tableManufacturer->save($manufacturer);
		
		}
		else {
			if  (isset($_GET['id'])) {
				$result = $this->tableManufacturer->find('id', $_GET['id']);
				$manufacturer = $result[0];
			}
			else  {
				$manufacturer = false;
			}

			return [
				'template' => 'editmanufacturertemplate.php',
				'variables' => ['manufacturer' => $manufacturer],
				'title' => 'Edit Manufacturer'
			];
		}
	}
}
