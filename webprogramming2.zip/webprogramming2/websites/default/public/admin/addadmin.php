<?php
session_start();
// requirements for all the pages
require '../Functions/loadTemplate.php';
// requirements for all the pages

require '../dbconnection.php';
// requirements for all the pages
require '../DatabasePage/Database.php';
// requirements for all the pages
require '../allControllers/controllerAdmin.php';
// requirements for all the pages
$admin = new Database($pdo,'admins','id');
// requirements for all the pages
$manucontrol= new controllerAdmin($admin);
// requirements for all the pages
$val=$manucontrol->edit();
// requirements for all the pages
$output = loadTemplate('../templatesPage/addadmintemplate.php',[]);
// requirements for all the pages
require '../templatesPage/layout.php';
?>