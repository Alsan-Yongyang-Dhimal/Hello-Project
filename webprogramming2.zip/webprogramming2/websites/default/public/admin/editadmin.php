<?php
session_start();
require '../Functions/loadTemplate.php';
require '../dbconnection.php';
require '../DatabasePage/Database.php';
require '../allControllers/controllerAdmin.php';
$admin = new Database($pdo,'admins','id');
$manucontrol= new controllerAdmin($admin);
$val=$manucontrol->edit();
$output = loadTemplate('../templatesPage/editadmintemplate.php',$val['variables']);
require '../templatesPage/layout.php';
?>