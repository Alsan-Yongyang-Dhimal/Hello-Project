<?php
session_start();
require '../Functions/loadTemplate.php';
require '../dbconnection.php';
require '../DatabasePage/Database.php';
require '../allControllers/controllerArticles.php';
$alsanarticle = new Database($pdo,'articles','id');
$manucontrol= new controllerArticle($alsanarticle);
$val=$manucontrol->delete();
$output = loadTemplate('../templatesPage/deletearticletemplate.php',[]);
require '../templatesPage/layout.php';
?>