<?php
session_start();
require '../Functions/loadTemplate.php';
require '../dbconnection.php';
require '../DatabasePage/Database.php';
require '../allControllers/controllerArticles.php';
$alsanarticle = new Database($pdo,'articles','id');
$manucontrol= new controllerArticle($alsanarticle);
$val=$manucontrol->edit();
$output = loadTemplate('../templatesPage/addarticletemplate.php',[]);
require '../templatesPage/layout.php';
?>