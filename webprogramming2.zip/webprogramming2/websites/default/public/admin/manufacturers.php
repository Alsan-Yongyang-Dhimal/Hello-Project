<?php
session_start();
//calling all the values bye this page
require '../Functions/loadTemplate.php';
//calling all the values bye this page
require '../dbconnection.php';
//calling all the values bye this page
require '../DatabasePage/Database.php';
//calling all the values bye this page
require '../allControllers/controllerManufacturer.php';
//calling all the values bye this page
$manufacturer = new Database($pdo,'manufacturers','id');
//calling all the values bye this page
$manucontrol= new controllerManufacturer($manufacturer);
//calling all the values bye this page
$val=$manucontrol->list();
//calling all the values bye this page
$output = loadTemplate('../templatesPage/manufacturertemplate.php',$val['variables']);
//calling all the values bye this page
require '../templatesPage/layout.php';
?>