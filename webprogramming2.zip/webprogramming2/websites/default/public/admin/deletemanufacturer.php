<?php
session_start();
//this file is for all the values deleteing the itemls
require '../Functions/loadTemplate.php';
//this file is for all the values deleteing the itemls
require '../dbconnection.php';
//this file is for all the values deleteing the itemls
require '../DatabasePage/Database.php';
//this file is for all the values deleteing the itemls
require '../allControllers/controllerManufacturer.php';
//this file is for all the values deleteing the itemls
$manufacturer = new Database($pdo,'manufacturers','id');
//this file is for all the values deleteing the itemls
$manucontrol= new controllerManufacturer($manufacturer);
//this file is for all the values deleteing the itemls
$val=$manucontrol->delete();
//this file is for all the values deleteing the itemls
$output = loadTemplate('../templatesPage/deletemanufacturertemplate.php',[]);
//this file is for all the values deleteing the itemls
require '../templatesPage/layout.php';
?>