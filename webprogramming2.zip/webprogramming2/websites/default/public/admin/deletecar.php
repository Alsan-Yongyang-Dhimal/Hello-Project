<?php
session_start();
//deleteing al the values of the cars
require '../Functions/loadTemplate.php';
//deleteing al the values of the cars
require '../dbconnection.php';
//deleteing al the values of the cars
require '../DatabasePage/Database.php';
//deleteing al the values of the cars
require '../allControllers/controllerCars.php';
//deleteing al the values of the cars
$car= new Database($pdo,'cars','id');
//deleteing al the values of the cars
$manufacturer= new Database($pdo,'manufacturers','id');
//deleteing al the values of the cars
$carcontrol= new controllerCars($car,$manufacturer);
//deleteing al the values of the cars
$val=$carcontrol->delete();
//deleteing al the values of the cars
$output = loadTemplate('../templatesPage/deletecarstemplate.php',[]);
//deleteing al the values of the cars
require '../templatesPage/layout.php';
?>