<?php
session_start();
require '../Functions/loadTemplate.php';
require '../dbconnection.php';
require '../DatabasePage/Database.php';
require '../allControllers/controllerCars.php';
$alsancar= new Database($pdo,'cars','id');
$alsanmanufacturer= new Database($pdo,'manufacturers','id');
$alsancarcontrol= new controllerCars($alsancar,$alsanmanufacturer);
$alsanval=$alsancarcontrol->list();

$output = loadTemplate('../templatesPage/admincarstemplate.php',$alsanval['variables']);
require '../templatesPage/layout.php';

?>
