<?php
session_start();
//all the fields should be added  heree
require '../Functions/loadTemplate.php';
//all the fields should be added  heree
require '../dbconnection.php';
//all the fields should be added  heree
require '../DatabasePage/Database.php';
//all the fields should be added  heree
require '../allControllers/controllerArticles.php';
//all the fields should be added  heree
$alsanarticle = new Database($pdo,'articles','id');
//all the fields should be added  heree
$manucontrol= new controllerArticle($alsanarticle);
//all the fields should be added  heree
$val=$manucontrol->list();
//all the fields should be added  heree
$output = loadTemplate('../templatesPage/articletemplate.php',$val['variables']);
//all the fields should be added  heree
require '../templatesPage/layout.php';
?>