<?php
session_start();
require '../Functions/loadTemplate.php';
require '../dbconnection.php';
require '../DatabasePage/Database.php';
require '../allControllers/controllerManufacturer.php';

$manufacturer = new Database($pdo,'manufacturers','id');
$manucontrol= new controllerManufacturer($manufacturer);
$val=$manucontrol->edit();
$output = loadTemplate('../templatesPage/editmanufacturertemplate.php',$val['variables']);
require '../templatesPage/layout.php';
?>