<?php
session_start();
//all the field for the requirements
require '../Functions/loadTemplate.php';
//all the field for the requirements
require '../dbconnection.php';
//all the field for the requirements
require '../DatabasePage/Database.php';
//all the field for the requirements
require '../allControllers/controllerAdmin.php';
//all the field for the requirements
$admin = new Database($pdo,'admins','id');
//all the field for the requirements
$manucontrol= new controllerAdmin($admin);
//all the field for the requirements
$val=$manucontrol->delete();
//all the field for the requirements
$output = loadTemplate('../templatesPage/deleteadmintemplate.php',[]);
//all the field for the requirements
require '../templatesPage/layout.php';
?>