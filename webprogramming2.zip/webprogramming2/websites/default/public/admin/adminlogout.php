<?php
        //used to start a new session or resume existing one
        session_start();
        //removes session
		session_unset();
        //destroys all of the data
		session_destroy();
        //path to the index
		header('location: ../admin/index.php');
?>