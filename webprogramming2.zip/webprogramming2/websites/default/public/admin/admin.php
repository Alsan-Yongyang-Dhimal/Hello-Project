<?php
session_start();
//all for the pages is essentails
require '../Functions/loadTemplate.php';
//all for the pages is essentails
require '../dbconnection.php';
//all for the pages is essentails
require '../DatabasePage/Database.php';
//all for the pages is essentails
require '../allControllers/controllerAdmin.php';
//all for the pages is essentails
$admin = new Database($pdo,'admins','id');
//all for the pages is essentails
$manucontrol1= new controllerAdmin($admin);
//all for the pages is essentails
$val=$manucontrol1->list();
//all for the pages is essentails
$output = loadTemplate('../templatesPage/admintemplate.php',$val['variables']);
//all for the pages is essentails
require '../templatesPage/layout.php';
?>