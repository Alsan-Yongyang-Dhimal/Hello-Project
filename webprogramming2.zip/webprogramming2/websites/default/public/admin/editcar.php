<?php
session_start();
require '../Functions/loadTemplate.php';
require '../dbconnection.php';
require '../DatabasePage/Database.php';
require '../allControllers/controllerCars.php';
$car= new Database($pdo,'cars','id');
$manufacturer= new Database($pdo,'manufacturers','id');
$carcontrol= new controllerCars($car,$manufacturer);
$val=$carcontrol->edit();
$output = loadTemplate('../templatesPage/editcarstemplate.php',$val['variables']);
require '../templatesPage/layout.php';
?>