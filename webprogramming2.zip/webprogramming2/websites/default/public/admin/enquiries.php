<?php
session_start();
require '../Functions/loadTemplate.php';
require '../dbconnection.php';
require '../DatabasePage/Database.php';
require '../allControllers/controllerEnquiry.php';

$alsanenquiry = new Database($pdo,'enquiries','id');
$manucontrol= new controllerEnquiry($alsanenquiry);
$alsanval=$manucontrol->list();
$output = loadTemplate('../templatesPage/enquirytemplate.php',$alsanval['variables']);
require '../templatesPage/layout.php';
?>