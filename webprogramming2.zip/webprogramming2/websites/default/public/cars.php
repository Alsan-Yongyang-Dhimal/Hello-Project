<?php
session_start();
//calling all the requirements for all the paages cwhich are here linked here
require './Functions/loadTemplate.php';
//calling all the requirements for all the paages cwhich are here linked here
require 'dbconnection.php';
//calling all the requirements for all the paages cwhich are here linked here
require './DatabasePage/Database.php';
//calling all the requirements for all the paages cwhich are here linked here
require './allControllers/controllerCars.php';
//calling all the requirements for all the paages cwhich are here linked here
$car= new Database($pdo,'cars','id');
//calling all the requirements for all the paages cwhich are here linked here
$manufacturer= new Database($pdo,'manufacturers','id');
//calling all the requirements for all the paages cwhich are here linked here
$carcontrol= new controllerCars($car,$manufacturer);
//calling all the requirements for all the paages cwhich are here linked here
$val=$carcontrol->list();
//calling all the requirements for all the paages cwhich are here linked here
$output = loadTemplate('./templatesPage/carstemplate.php',$val['variables']);
//calling all the requirements for all the paages cwhich are here linked here
require './templatesPage/layout.php';
?>