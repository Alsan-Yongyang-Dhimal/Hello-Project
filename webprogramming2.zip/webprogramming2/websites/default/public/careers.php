<?php
//calling all the pages for the careerspage here
require './Functions/loadTemplate.php';
//calling all the pages for the careerspage here
$output = loadTemplate('./templatesPage/careerstemplate.php',[]);
//calling all the pages for the careerspage here
require './templatesPage/layout.php';

?>