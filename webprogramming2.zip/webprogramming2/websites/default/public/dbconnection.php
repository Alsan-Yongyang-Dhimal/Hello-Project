<?php
//calling the all the values for the connection for all the pages


$servername = 'db'; 

$username = 'student';  

$password = 'student';



try{
$pdo = new PDO("mysql:host=$servername;dbname=cars", $username, $password); 


$pdo->setAttribute(PDO::ATTR_ERRMODE , PDO::ERRMODE_EXCEPTION);
 } 
 
 catch(PDOExecption $e) {
 
    echo "Connection Failed : " . $e->getMessage();
 } 
?>