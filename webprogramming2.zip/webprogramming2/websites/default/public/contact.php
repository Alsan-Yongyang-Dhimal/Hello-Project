<?php
session_start();
// calling the all requirements for all the pages from here
require './Functions/loadTemplate.php';
// calling the all requirements for all the pages from here
require './dbConnection.php';
// calling the all requirements for all the pages from here
require './DatabasePage/Database.php';
// calling the all requirements for all the pages from here
require './allControllers/controllerEnquiry.php';
// calling the all requirements for all the pages from here

$alsanenquiry= new Database($pdo,'enquiries','id');
// calling the all requirements for all the pages from here
$alsancontrol= new controllerEnquiry($alsanenquiry);
// calling the all requirements for all the pages from here
$val=$alsancontrol->edit();
// calling the all requirements for all the pages from here
$output = loadTemplate('./templatesPage/contacttemplate.php',[]);
// calling the all requirements for all the pages from here
require './templatesPage/layout.php';
?>