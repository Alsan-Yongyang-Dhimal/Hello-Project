<?php
// calling it
class Database {
	//having tha same
	private $pdo;
	//here we oo
	private $table;
	//calling the keys
	private $primaryKey;


	//constructig all the fiels
	public function __construct($pdo, $table, $primaryKey) {
		$this->pdo = $pdo;
		//here
		$this->table = $table;
		// here
		$this->primaryKey = $primaryKey;
	}
  
	// same as before
	public function find($field1, $value1) {
		// all here
		$alsanstmt = $this->pdo->prepare('SELECT * FROM ' . $this->table . ' WHERE ' . $field1 . ' = :value');

		$criteria = [
			'value' => $value1
		];
		$alsanstmt->execute($criteria);
    //  return all
		return $alsanstmt->fetchAll();
	}

// having all it
	public function findAll() {
		$alsanstmt = $this->pdo->prepare('SELECT * FROM ' . $this->table);
// all finding all it
		$alsanstmt->execute();
// values here
		return $alsanstmt->fetchAll();
	}

	public function insert($record1) {
	// inserting the values
			unset($record1['submit']);
	        $keys = array_keys($record1);

	        $value = implode(', ', $keys);
	        $valuesWithColon = implode(', :', $keys);

	        $query1 = 'INSERT INTO ' . $this->table . ' (' . $value . ') VALUES (:' . $valuesWithColon . ')';
          
	        $alsanstmt = $this->pdo->prepare($query1);

	        $alsanstmt->execute($record1);
	}

	public function delete($id) {
		$alsanstmt = $this->pdo->prepare('DELETE FROM ' . $this->table . ' WHERE ' . $this->primaryKey . ' = :id');
		$criteria1 = [
			'id' => $id
		];
		$alsanstmt->execute($criteria1);
	}


	public function save($record1) {
		try {
			$this->insert($record1);
		}
		catch (Exception $e) {
			$this->update($record1);
		}
	}

	public function update ($record1) {
		     unset($record1['submit']);
	         $query1 = 'UPDATE ' . $this->table . ' SET ';

	         $parameters1 = [];
	         foreach ($record1 as $key => $value) {
				if($key=== 'id') continue;
	                $parameters1[] = $key . ' = :' .$key;
	         }
          //all the fields
	         $query1 .= implode(', ', $parameters1);
	         $query1 .= ' WHERE ' . $this->primaryKey . ' = :primaryKey';
	         $record1['primaryKey'] = $record1['id'];
		 //runningthe 
			unset($record1['id']);
          
			
	         $alsanstmt = $this->pdo->prepare($query1);
	         $alsanstmt->execute($record1);
	}
	
	
	
	

}