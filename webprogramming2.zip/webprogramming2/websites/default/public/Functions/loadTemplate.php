<?php
// all gthe values calling
function loadTemplate($fileName, $templateVars) {
        //calling all here
	extract($templateVars);
        // here startinh
        ob_start();
        // /calling and requiremenr of file
        require $fileName;
        // here is things
        $contents = ob_get_clean();
        // here
        return $contents;       
}

