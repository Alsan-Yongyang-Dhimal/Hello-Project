<main class="admin">

	<section class="left">
		<ul>
			<!-- linking all the pages by refering here -->
			<li><a href="manufacturers.php">Manufacturers</a></li>
				<!-- linking all the pages by refering here -->
			<li><a href="cars.php">Cars</a></li>
				<!-- linking all the pages by refering here -->
			<li><a href="enquiries.php">Enquiries</a></li>
				<!-- linking all the pages by refering here -->
			<li><a href="admin.php">Admin</a></li>	
				<!-- linking all the pages by refering here -->
			<li><a href="articles.php">Articles</a></li>
			<li><a href="adminlogout.php">Log out</a></li>		

		</ul>
	</section>

	<section class="right">

		
		
	<?php
          //all for the loginsessionshere
		if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
		?>


			<h2>Manufacturers</h2>

			<a class="new" href="addmanufacturer.php">Add new manufacturer</a>
           <!-- print all the values for table -->
			<?php
			echo '<table>';
		//  print all the values for table 
			echo '<thead>';
			echo '<tr>';
			//  print all the values for table 
			echo '<th>Name</th>';
			//  print all the values for table 
			echo '<th style="width: 5%">&nbsp;</th>';
			//  print all the values for table 
			echo '<th style="width: 5%">&nbsp;</th>';
			//  print all the values for table 
			echo '</tr>';

		
        //   using the loops here for showning the values here
			foreach ($manufacturer as $category) {
				echo '<tr>';
				//  print all the values for table 
				echo '<td>' . $category['name'] . '</td>';
				//  print all the values for table 
				echo '<td><a style="float: right" href="editmanufacturer.php?id=' . $category['id'] . '">Edit</a></td>';
				echo '<td><form method="post" action="deletemanufacturer.php">
				<input type="hidden" name="id" value="' . $category['id'] . '" />
				<input type="submit" name="submit" value="Delete" />
				</form></td>';
				echo '</tr>';
			}
// calling the echofunction for the printing here
			echo '</thead>';
			echo '</table>';

		}

		else {
			?>
			<h2>Log in</h2>
             <!-- form for the section of login here  -->
			<form action="index.php" method="post">
				<label>Username</label>
				<input type="text" name="username" />

				<label>Password</label>
				<input type="password" name="password" />

				<input type="submit" name="submit" value="Log In" />
			</form>
		<?php
		}
	?>

</section>
	</main>