<main class="admin">

	<section class="left">
		<ul>
			<li><a href="manufacturers.php">Manufacturers</a></li>
			<li><a href="cars.php">Cars</a></li>
			<li><a href="enquiries.php"> Enquiries</a></li>
			<li><a href="admin.php">Admin</a></li>
			<li><a href="articles.php">Articles</a></li>
			<li><a href="adminlogout.php">Log out</a></li>	

		</ul>
	</section>

	<section class="right">
	
		
	<?php


	
	
		if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {

		


		?>

			<h2>Edit Car</h2>

			<form action="" method="POST" enctype="multipart/form-data">

			<input type="hidden" name="id" value="<?php echo $car['id']; ?>" />
				<label>Name</label>

				<input type="text" name="name" value="<?php echo $car['name']; ?>" />

				<label>Description</label>
				<textarea name="description"></textarea>

				<label>Price</label>
				<input type="text" name="price" value="<?php echo $car['description']; ?>" />

				
				<label>Old Price</label>
				<input type="text" name="oldprice" value="<?php echo $car['oldprice']; ?>" />

				
				<label>Engine Type</label>
				<input type="text" name="enginetype" value="<?php echo $car['enginetype']; ?> " />

				
				<label>Mileage</label>
				<input type="text" name="mileage" value="<?php echo $car['mileage']; ?>" />

				


				<label>Category</label>

				<select name="manufacturerId">
				<?php
					

					foreach ($manufacturer as $row) {
						if ($car['categoryId'] == $row['id']) {
							echo '<option selected="selected" value="' . $row['id'] . '">' . $row['name'] . '</option>';
						}
						else {
							echo '<option value="' . $row['id'] . '">' . $row['name'] . '</option>';	
						}
						
					}

				?>

				</select>


				<?php

					if (file_exists('../productimages/' . $car['id'] . '.jpg')) {
						echo '<img src="../productimages/' . $car['id'] . '.jpg" />';
					}
				?>
				<label>Product image</label>

				<input type="file" name="image[]" />

				<input type="submit" name="submit" value="save" />

			</form>

		<?php
		}

		else {
			?>
			<h2>Log in</h2>

			<form action="index.php" method="post">
				<label>Username</label>
				<input type="text" name="username" />

				<label>Password</label>
				<input type="password" name="password" />

				<input type="submit" name="submit" value="Log In" />
			</form>
		<?php
		}

	?>

</section>
	</main>