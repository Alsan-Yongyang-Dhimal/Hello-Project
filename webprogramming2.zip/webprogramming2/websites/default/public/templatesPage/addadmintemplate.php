<?

?>
<main class="home">
<!-- header for newly -->
			<h2>Register New Admin</h2>
      
			<form action="" method="post">
				<label>User Name</label>
				<input type="text" name="username" />
                  
                <label>Email</label>
				<input type="text" name="email" />
                <!-- for the passwords required -->
                <label>Password</label>
				<input type="text" name="password" />
				
				<label>Contact Number</label>
				<!-- for the field of numbers -->
				<input type="text" name="contactnumber" />
				
							<!-- for the submitting the buttons here -->
				<input type="submit" name="submit" value="Register" />
			</form>
			
			
    </main>
