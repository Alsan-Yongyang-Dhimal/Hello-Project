<main class="admin">

	<section class="left">
		<ul>
			<!-- for all the pages -->
			<li><a href="manufacturers.php">Manufacturers</a></li>
			<!-- for all the pages -->
			<li><a href="cars.php">Cars</a></li>
			<!-- for all the pages -->
			<li><a href="enquiries.php">Enquiries</a></li>
			<!-- for all the pages -->
			<li><a href="admin.php">Admin</a></li>
			<!-- for all the pages -->
			<li><a href="articles.php">Articles</a></li>
			<li><a href="adminlogout.php">Log out</a></li>	

		</ul>
	</section>

	<section class="right">

		
		
	<?php
// starting it all
		if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
		?>


			<h2>Admin Table</h2>

			<a class="new" href="addadmin.php">Add new Admin</a>
<!-- for the fields -->
			<?php
			echo '<table>';
			echo '<thead>';
			echo '<tr>';
			echo '<th>UserName</th>';
			echo '<th>Email</th>';
			echo '<th>Password</th>';
			echo '<th>Contact Number</th>';
			//all the tables
			echo '<th style="width: 5%">&nbsp;</th>';
			echo '<th style="width: 5%">&nbsp;</th>';
			echo '</tr>';

			

			// 
			foreach ($admin as $adm) {
				echo '<tr>';
				echo '<td>' . $adm['username'] . '</td>';
				echo '<td>' . $adm['email'] . '</td>';
				echo '<td>' . $adm['password'] . '</td>';
				echo '<td>' . $adm['contactnumber'] . '</td>';
				echo '<td><a style="float: right" href="editadmin.php?id=' . $adm['id'] . '">Edit</a></td>';
				echo '<td><form method="post" action="deleteadmin.php">
				<input type="hidden" name="id" value="' . $adm['id'] . '" />
				<input type="submit" name="submit" value="Delete" />
				</form></td>';
				echo '</tr>';
			}
			

			echo '</thead>';
			echo '</table>';

		}

		else {
			?>
			<h2>Log in</h2>

			<form action="index.php" method="post">
				<label>Username</label>
				<input type="text" name="username" />

				<label>Password</label>
				<input type="password" name="password" />

				<input type="submit" name="submit" value="Log In" />
			</form>
		<?php
		}
	?>

</section>
	</main>