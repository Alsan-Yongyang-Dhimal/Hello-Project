<main class="home">
	<h3>Claire’s Cars currently has no job opportunities available, but keep checking as new positions become available regularly!</h3>
</main>