    <main class="home">
		<?php
        // using the loops here as well
        foreach ($article as $alsanarticle) {
            // print all the division detailing here
            echo '<div class="details">';
            // prints the alsanarticle titles here
            echo '<h3>Title: ' . $alsanarticle['title'] . '</h3>';
            // prints the alsandesc here
            echo '<p>Description: ' . $alsanarticle['description'] . '</p>';
            // this is for the division
            echo '</div>';
            // this is for the lines
            echo '<hr>';
            // this is also for the lines
            echo '<hr>';
        }
        ?>

	</main>
	
	