<main class="admin">

	<section class="left">
		<ul>
			<li><a href="manufacturers.php">Manufacturers</a></li>
			<li><a href="cars.php">Cars</a></li>
			<li><a href="enquiries.php"> Enquiries</a></li>
			<li><a href="admin.php">Admin</a></li>
			<li><a href="articles.php">Articles</a></li>
			<li><a href="adminlogout.php">Log out</a></li>	

		</ul>
	</section>

	<section class="right">

		
	<?php


	
		if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
		?>


			<h2>Edit Admin</h2>
            <form action="" method="post">
            <input type="hidden" name="id" value="<?php echo $admin['id']; ?>" />
				<label>User Name</label>
				<input type="text" name="username" value="<?php echo $admin['username']; ?>" />
                  
                <label>Email</label>
				<input type="text" name="email" value="<?php echo $admin['email']; ?>" />

                <label>Password</label>
				<input type="text" name="password" value="<?php echo $admin['password']; ?>"/>
				
				<label>Contact Number</label>
				<input type="text" name="contactnumber" value="<?php echo $admin['contactnumber']; ?>"/>
				
							
				<input type="submit" name="submit" value="save" />
			</form>

		<?php
		}

		else {
			?>
			<h2>Log in</h2>

			<form action="index.php" method="post">
				<label>Username</label>
				<input type="text" name="username" />

				<label>Password</label>
				<input type="password" name="password" />

				<input type="submit" name="submit" value="Log In" />
			</form>
		<?php
		}

	
	?>


</section>
	</main>

