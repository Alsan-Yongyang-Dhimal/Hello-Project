<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="/styles.css"/>
		<title><?$title?></title>
	</head>
	<body>
	<header>
		<section>
			<aside>
				<!-- for the top right section showning the values here -->
				<h3>Opening Hours:</h3>
				<!-- for the top right section showning the values here -->
				<p>Mon-Fri: 09:00-17:30</p>
				<!-- for the top right section showning the values here -->
				<p>Sat: 09:00-17:00</p>
				<!-- for the top right section showning the values here -->
				<p>Sun: Closed</p>
			</aside>
			<img src="/images/logo.png"/>


		</section>
	</header>
	<nav>
		<ul>
				<!-- linking all the pages by refering here -->
			<li><a href="/">Home</a></li>
			<!-- linking all the pages by refering here -->
			<li><a href="/cars.php">Showroom</a></li>
			<!-- linking all the pages by refering here -->
			<li><a href="/about.php">About Us</a></li>
			<!-- linking all the pages by refering here -->
			<li><a href="/contact.php">Contact us</a></li>
			<!-- linking all the pages by refering here -->
			<li><a href="/careers.php">Claire's Careers</a></li>
			<!-- linking all the pages by refering here -->
			<li><a href="admin/index.php">Admin Panel</a></li>
		</ul>
	</nav>
     <img src="../images/randombanner.php"/>
    
	<!-- this is for the all the pages for the  -->
      <?=$output?>
    

<footer>
	<!-- showing thw copyright section here as well -->
		&copy; Claire's Cars 2018
	</footer>
</body>
</html>
