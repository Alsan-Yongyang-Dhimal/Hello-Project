<? // here we starting the class here called admin
?>
<main class="admin">
<!-- here starting the html here -->
	<section class="left">
		<ul>
			<!-- here refering the manu php classes here -->
			<li><a href="manufacturers.php">Manufacturers</a></li>
			<!-- here refering the cars php classes here -->
			<li><a href="cars.php">Cars</a></li>
			<!-- here refering the enquiry php classes here -->
			<li><a href="enquiries.php"> Enquiries</a></li>
			<li><a href="admin.php">Admin</a></li>
			<li><a href="articles.php">Articles</a></li>
			<li><a href="adminlogout.php">Log out</a></li>	

		</ul>
	</section>

	<section class="right">
	<?php
//   starting the isset keyword for the login in for admin section
		if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
		?>

			<h2>Add Car</h2>
           <!-- starting the form herer for the carstemplates here -->
			<form action="" method="POST" enctype="multipart/form-data">
				<!-- describing the car model name -->
				<label>Car Model</label>
				<input type="text" name="name" />
                 <!-- for the details of the cars here -->
				<label>Description</label>
				<textarea name="description"></textarea>
                <!-- for the price of the cars details -->
				<label>Price</label>
				<input type="text" name="price" />
                <!-- price of the old car here -->
				<label>Old Price</label>
				<input type="text" name="oldprice" />
                <!-- the type of the engine here as well -->
				<label>Engine Type</label>
				<input type="text" name="enginetype" />
                 <!-- field for the car km age -->
				<label>Mileage</label>
				<input type="text" name="mileage" />
				

                <!-- for the category that are shown in the pages -->

				<label>Category</label>
                <!-- selecting the manufacturers id selecting -->
				<select name="manufacturerId">
				<?php
					// calling the loops here
					foreach ($manufacturer as $alsanrow) {
						// calling gthe values for all the manu
						echo '<option value="' . $alsanrow['id'] . '">' . $alsanrow['name'] . '</option>';
					}

				?>

				</select>
               <!-- for the images that should be uploaded -->
				<label>Image</label>
                <!-- calling the file here for the images -->
				<input type="file" name="image[]"   />
                 <!-- for adding the new cars here -->
				<input type="submit" name="submit" value="Add Car" />

			</form>
			

		
		<?php
		}

		else {
			?>
			<!-- for the login page for admin -->
			<h2>Log in</h2>
			<form action="index.php" method="post">
				<!-- for the user data here -->
				<label>Username</label>
				<input type="text" name="username" />

				<label>Password</label>
				<input type="password" name="password" />
                <!-- for the all the field that should be send by the button -->
				<input type="submit" name="submit" value="Log In" />
			
			</form>
		<?php
		}
	?>

</section>
	</main>