<main class="home">

				<h2>Enquiries</h2>

			<form action="" method="post">
				<label>Full Name</label>
				<input type="text" name="fullname" />

				<label>Email</label>
				<input type="text" name="email" />

				<label>Contact Number</label>
				<input type="text" name="contactnumber" />
				
				<label>Enquiry</label>
				<textarea name="enquiry"></textarea>

				<input type="submit" name="submit" value="Send" />
			</form>
</main>