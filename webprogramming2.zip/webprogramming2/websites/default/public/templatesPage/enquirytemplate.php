<main class="admin">

				<section class="left">
		<ul>
			<!-- linking al the pages by refering here -->
			<li><a href="manufacturers.php">Manufacturers</a></li>
				<!-- linking al the pages by refering here -->
			<li><a href="cars.php">Cars</a></li>
				<!-- linking al the pages by refering here -->
			<li><a href="enquiries.php">Enquiries</a></li>	
				<!-- linking al the pages by refering here -->
			<li><a href="admin.php">Admin</a></li>	
				<!-- linking al the pages by refering here -->
			<li><a href="articles.php">Articles</a></li>
			<li><a href="adminlogout.php">Log out</a></li>			
			
		
		</ul>
	</section>


	<section class="right">
		
	<?php
        // starting the new classsession for the login sections heres
		if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
		?>
       
          <!-- for showing the below text -->
			<h2> Enquiries Table Here</h2>


		<?php
		// for creating the table for all the fields
			echo '<table>';
			// for creating the table for all the fields
			echo '<thead>';
			// for creating the table for all the fields
			echo '<tr>';
			// for creating the table for all the fields
			echo '<th style="width: 20%">Name</th>';
			// for creating the table for all the fields
			echo '<th style="width: 20%">Email</th><br>';
			// for creating the table for all the fields
			echo '<th style="width: 20%">Contact Number</th>';
			// for creating the table for all the fields
			echo '<th style="width: 80%">Enquiry</th>';
			
  
		
        // creating the loops for better 
			foreach ($enquiry as $enquiry) {
				// using the tag
				echo '<tr>';
				// using also tag for all the fields
				echo '<td>' . $enquiry['fullname'] . '</td>';
					// using also tag for all the fields
				echo '<td>' . $enquiry['email'] . '</td>';
					// using also tag for all the fields
				echo '<td>' . $enquiry['contactnumber'] . '</td>';
					// using also tag for all the fields
				echo '<td>' . $enquiry['enquiry'] . '</td>';
					// using also tag for all the fields
				echo '<td> <form method="post" action="enquiries.php">
				<input type="hidden" name="id" value="' . $enquiry['id'] . '" />
				
				</form></td>';
				echo '</tr>';
			}

			echo '</thead>';
			echo '</table>';
		}
    
		else {
			?>
			<h2>Log in</h2>

			<form action="admin.php" method="post">
				<label>Username</label>
				<input type="text" name="username" />
				<label>Password</label>
				<input type="password" name="password" />

				<input type="submit" name="submit" value="Log In" />
			</form>
		<?php
		}
	?>

</section>
	</main>