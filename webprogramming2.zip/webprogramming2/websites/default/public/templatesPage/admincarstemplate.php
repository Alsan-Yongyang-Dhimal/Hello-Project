<main class="admin">

	<section class="left">
		<ul>
			<li><a href="manufacturers.php">Manufacturers</a></li>
			<li><a href="cars.php">Cars</a></li>
			<li><a href="enquiries.php">Enquiries</a></li>
			<li><a href="admin.php">Admin</a></li>
			<li><a href="articles.php">Articles</a></li>
			<li><a href="adminlogout.php">Log out</a></li>	
			

		</ul>
	</section>


	<section class="right">
		
	<?php
        //  for the login data here
		if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
		?>


			<h2>Cars</h2>

			<a class="new" href="addcar.php">Add new car</a>

			<?php
			// making the table for cars
			echo '<table>';
			// making the table for cars
			echo '<thead>';
			// making the table for cars
			echo '<tr>';
				// making the table for cars
			echo '<th>Model</th>';
			echo '<th style="width: 15%">Price</th>';
			echo '<th>Old Price</th>';
				// making the table for cars
			echo '<th style="width: 15%">Engine Type</th>';
				// making the table for cars
			echo '<th style="width: 15%">Mileage</th>';
				// making the table for cars
			echo '<th style="width: 5%">&nbsp;</th>';
				// making the table for cars
			echo '<th style="width: 5%">&nbsp;</th>';
				// making the table for cars
			echo '</tr>';

		
            // calling the loops here
			foreach ($car as $car) {
				echo '<tr>';
				//making the table
				echo '<td>' . $car['name'] . '</td>';
					//making the table
				echo '<td>£' . $car['price'] . '</td>';
					//making the table
				echo '<td>£' . $car['oldprice'] . '</td>';
					//making the table
				echo '<td>' . $car['enginetype'] . '</td>';
					//making the table
				echo '<td>' . $car['mileage'] . 'km/ltr</td>';
					//making the table
	           	echo '<td><a style="float: right" href="editcar.php?id=' . $car['id'] . '">Edit</a></td>';
				echo '<td><form method="post" action="deletecar.php">
				<input type="hidden" name="id" value="' . $car['id'] . '" />
				<input type="submit" name="submit" value="Delete" />
				</form></td>';
				echo '</tr>';
			}
        //    callingthe
			echo '</thead>';
			echo '</table>';

		}

		else {
			?>
			<h2>Log in</h2>

			
			<form action="index.php" method="post">
				<label>Username</label>
				<input type="text" name="username" />

				<label>Password</label>
				<input type="password" name="password" />

				<input type="submit" name="submit" value="Log In" />
		
			</form>
		<?php
		}
	?>

</section>
	</main>