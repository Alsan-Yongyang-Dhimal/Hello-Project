<main class="admin">

	<section class="left">
		<ul>
			
		<?php
		//calling the loops here
			foreach ($manufacturer as $alsanval) {
				?>
				
				<li><a href="?id=<?php echo $alsanval['id'];?>">
				<?php echo $alsanval['name']?></a></li>
				<?php
			}
			?>
		</ul>
	</section> 
  
	<section class="right">

		<h1>Our cars</h1>

	<ul class="cars">


	<?php
	


	foreach ($car as $car) {
		
		echo '<li>';
// for processing the images
		if (file_exists('images/cars/' . $car['id'] . '.jpg')) {
			echo '<a href="images/cars/' . $car['id'] . '.jpg"><img src="images/cars/' . $car['id'] . '.jpg" /></a>';
		}

		echo '<div class="details">';
		foreach($manufacturer as $alsan){
			if($alsan['id']==$car['manufacturerId'])
		    echo '<h2> ' . $alsan['name'] . ' ' . $car['name'] . '</h2>';
		}
		// calling al the values here
		echo '<h3>Latest Price: £' . $car['price'] . '</h3>';
		echo '<p>Description: ' . $car['description'] . '</p>';
		echo '<p>Old Price: £' . $car['oldprice'] . '</p>';
		echo '<p>Engine Type: ' . $car['enginetype'] . '</p>';
		echo '<p>Mileage: ' . $car['mileage'] . 'km/ltr</p>';

		echo '</div>';
		echo '</li>';
	}

	?>

</ul>

</section>
	</main>