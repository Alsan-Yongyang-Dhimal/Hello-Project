<main class="admin">

	<section class="left">
		<ul>
			<li><a href="manufacturers.php">Manufacturers</a></li>
			<li><a href="cars.php">Cars</a></li>
			<li><a href="enquiries.php"> Enquiries</a></li>
			<li><a href="admin.php">Admin</a></li>
			<li><a href="articles.php">Articles</a></li>
			<li><a href="adminlogout.php">Log out</a></li>	

		</ul>
	</section>

	<section class="right">

		
	<?php


	//   login function called here
		if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
		?>

<!-- adding the new manufacturers here on the page -->
			<h2>Add Manufacturer</h2>
                <!-- all the form is for the adding the manufacturers here -->
			<form action="" method="POST">
				<label>Name</label>
				<input type="text" name="name" />

                <!-- here are button  for adding  it -->
				<input type="submit" name="submit" value="Add Manufacturer" />

			</form>
			

		<?php
		}

		else {
			?>
			<h2>Log in</h2>
             <!-- calling the  -->
			<form action="index.php" method="post">
				<!-- calling the user data here for the  login here -->
				<label>Username</label>
				<input type="text" name="username" />
               <!-- for the pass data here -->
				<label>Password</label>
				<input type="password" name="password" />
                <!-- for the button of save -->
				<input type="submit" name="submit" value="Log In" />
			</form>
		<?php
		}


	?>


</section>
	</main>