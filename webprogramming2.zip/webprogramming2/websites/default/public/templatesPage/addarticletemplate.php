<main class="admin">

	<section class="left">
		<ul>
			<!-- for the manufacturerphp here -->
			<li><a href="manufacturers.php">Manufacturers</a></li>
			<!-- for the carsphp page heere -->
			<li><a href="cars.php">Cars</a></li>
			<!-- for then enquiriespaage here -->
			<li><a href="enquiries.php"> Enquiries</a></li>
			<!-- page -->
			<li><a href="admin.php">Admin</a></li>
			<!-- page -->
			<li><a href="articles.php">Articles</a></li>
			<li><a href="adminlogout.php">Log out</a></li>	

		</ul>
	</section>

	<section class="right">

		
	<?php


	//    starting the login sessioos here
		if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
		?>

           <!-- header for articles -->
			<h2>Add Articles</h2>
   
			<form action="" method="post">
				<label>Title</label>
				<input type="text" name="title" />

				<label>Description</label>
				<textarea name="description"></textarea>

				<input type="submit" name="submit" value="Add Article" />
			</form>
			
			

		<?php
		}

		else {
			?>
			<h2>Log in</h2>
<!-- for the login here -->
			<form action="index.php" method="post">
				<label>Username</label>
				<!-- for the userdata here name as well as pass -->
				<input type="text" name="username" />

				<label>Password</label>
				<input type="password" name="password" />
                <!-- login for the view -->
				<input type="submit" name="submit" value="Log In" />
			</form>
		<?php
		}

	
	?>


</section>
	</main>

