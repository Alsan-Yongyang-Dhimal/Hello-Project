<main class="home">
	<p>Welcome to Claire's Cars, Northampton's specialist in classic and import cars.</p>
</main>