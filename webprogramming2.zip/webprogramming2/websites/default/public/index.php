<?php
session_start();
//calling all the values that are essetials for calling
require './Functions/loadTemplate.php';
//calling all the values that are essetials for calling
require './dbconnection.php';
//calling all the values that are essetials for calling
require './DatabasePage/Database.php';
//calling all the values that are essetials for calling
require './allControllers/controllerArticles.php';
//calling all the values that are essetials for calling
$alsanarticle = new Database($pdo,'articles','id');
//calling all the values that are essetials for calling
$manucontrol= new controllerArticle($alsanarticle);
//calling all the values that are essetials for calling
$val=$manucontrol->list();
//calling all the values that are essetials for calling
$output = loadTemplate('./templatesPage/hometemplate.php',$val['variables']);
//calling all the values that are essetials for calling
require './templatesPage/layout.php';

?>


