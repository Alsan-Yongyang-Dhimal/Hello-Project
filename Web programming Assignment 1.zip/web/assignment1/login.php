<?php
//starting
session_start();
//connecting
require 'Admin/dbconnection.php';

//set into database
if(isset($_POST['Login'])){
	   //pasing the values  and selecting
		$alsan = $pdo->prepare("SELECT * FROM register_forms WHERE email =:email");
		//seeting the values
		$alsanc = [
				'email' =>$_POST['email'],
				
		];
		//
		$res = false;
		//running
		$alsan->execute($alsanc);
		//fetching
		if($alsan->rowCount() > 0){
			$ad = $alsan->fetch();
			//checking the pw
			if(password_verify($_POST['password'], $ad['password'])){
			$_SESSION['id'] = $ad['id'];
			//heading locations
			header('location:index.php');
		}
		else{
			$res = true;
		}
		}
	  // checking
		if($res == true){
			//pop up message here
			echo "<script type='text/javascript'>alert(' failed');</script>";
		}
}
?>







	<head>
		<link rel="stylesheet" href="style.css"/>
		<title>Northampton News-Login Portal</title>
	</head>
	<body>
		<header>
			<section>
				<h1>Northampton News</h1>
           </section>
</header>
		
		

<h2>Login Here</h2>
<fieldset>
<form action="login.php" method="POST">
<label class="Email">Email:</label>
<br>
<input type="text"  name="email" placeholder="  Email">
<br>
<label class="Pass">Password:</label>
<br>
<input type="password"  name="password" placeholder=" Password" >
<br>
<input type="submit" class="login-btn" name="Login" value="Submit">
<br>
<p>don't have an account?<a href="register.php"> Register Now</a></p>
	
</form>
</fieldset>

		
	</body>

