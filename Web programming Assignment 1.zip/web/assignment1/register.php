<?php
//connecting
require 'Admin/dbconnection.php';

//storing into database
if(isset($_POST['Register'])){
	//passing checking the values
	if($_POST['fullname']=="" || $_POST['email']=="" || $_POST['contact']=="" ||$_POST['password']==""){
		//pop up message
			echo "<script type='text/javascript'>alert('Please Fill all the Credentials');</script>";
	}
		else {
			//passing the values and insert
			$alsan = $pdo->prepare("INSERT INTO register_forms(fullname, contactnumber,email ,password)
								VALUES(:fullname, :contact,:email,:password )");
		
		$alsanc =[
		'fullname'=> $_POST['fullname'],
        'contact' => $_POST['contact'],
        'email' => $_POST['email'],
		'password' => password_hash($_POST['password'], PASSWORD_DEFAULT)
		];
		$alsan->execute($alsanc);
		//pop up message  here 
		echo "<script type='text/javascript'>alert(' Succesfully Register');</script>";
	}
}
?>


	<head>
		<link rel="stylesheet" href="style.css"/>
		<title>Northampton News- Register Page</title>
	</head>
	<body>
		<header>
			<section>
				<h1>Northampton News</h1>
           </section>
</header> 
		
		

<h2>Register Here</h2>
<fieldset>
<form action="register.php" method="POST">
<label class="Full">Full Name:</label>
<br>
<input type="text"  name="fullname" placeholder="  Full Name">
<br>
<label class="Contact">Contact No:</label>
<br>
<input type="text"  name="contact" placeholder="  Contact number">
<br>
<label class="Email">Email:</label>
<br>
<input type="text"  name="email" placeholder="  Email">
<br>
<label class="Pass">Password:</label>
<br>
<input type="password"  name="password" placeholder=" Password">
<br>
<input type="submit" class="reg-btn" name="Register" value="Register">

<p>already have an account?<a href="login.php"> login Now</a></p>
	
</form>
</fieldset>
<footer>
			&copy; Northampton News 2017
		</footer>


		
	</body>



