<?php 
require 'Admin/dbconnection.php';?>



<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="st.css"/>
		<title>Lates Article Page</title>
	</head>
	<body>
		<header>
			<section>
				<h1>Northampton News</h1>
			</section>
		</header>
		<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="latest.php">Latest Articles</a></li>
				<li><a href="register.php">Register/login user</a></li>
				 <li><a href="admin/adminregister.php">Admin Register</a></li>
				<li><a href="">Select Category</a>
		<ul>
						<?php 
                        //getting values from database
							$alsan = $pdo->query('SELECT category_id, title FROM categories');
                            //running
							$alsan->execute();
                            //loops using
							foreach ($alsan as $ad) {
								?>
								<li>
								<?php
                                //showing in the page
								echo '<a href="cat.php?cId='.$ad['category_id'].'">'.$ad['title'].'</a>';
								?>
								</li>
								<?php
							}
						?>
					</ul>
				</li>
			

			</ul>
		</nav>
		<img src="images/banners/randombanner.php" />
	 <main>
			
		

			<article>
				<h2>Weclome To The News</h2>
                		<ul>
				
				<?php

//passing the data
$adstmt =$pdo->query("SELECT * FROM articles ORDER BY date DESC");
$adstmt ->execute();
foreach ($adstmt as $a) {?>
	  <li>Title: <?php echo $a['title'] ?></li>
	  <li>Name: <?php echo $a['author'] ?></li>
      <li>Date: <?php echo $a['date'] ?></li>
	  <li>News: <?php echo $a['description'] ?></li>
	  <li>Category: <?php 
		$dhstmt = $pdo->query('SELECT title FROM categories ');
		$dhstmt->execute();
		foreach ($dhstmt as $d) {
			echo $d['title'];
		}
	
 	?>
	<?php
}
	?>
	
				</ul>
			

			</article>
		</main>

		<footer>
			&copy; Northampton News 2017
		</footer>

	</body>
</html>
