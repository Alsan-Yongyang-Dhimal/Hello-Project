<?php
//starting the new sesssions here
session_start();
//connecting the database
require 'dbconnection.php';

//when the  id is pressed
if (isset($_GET['aid'])) {
	//getting the value
		$aid = $_GET['aid'];
		//selecting the admins id
		$alsan = $pdo->prepare("SELECT * FROM admins WHERE admin_id = :aid");
		//passing the value
		$rcriteria = [
			'aid' => $aid
		];
		//running
		$alsan->execute($rcriteria);
		//fetching the data in alsan
		$run = $alsan-> fetch();
	}
	//when regbutton is pressed 
if(isset($_POST['reg'])){
	//update the admins values
		$alsan=$pdo->prepare("UPDATE admins SET
								fullname = :aname,
								email = :aemail
							
							");
		unset($_POST['reg']);
		//runnning the values
		$result = $alsan->execute($_POST);	
		//if set tru then
		if($result == true)	{
			//pop up message comes form javascipts
			echo "<script type='text/javascript'>alert(' Admin Record Updated');</script>";
			//passing the heading location here
			header('location:adminshow.php');
		}
		//pop up message comes here like
		else echo "<script type='text/javascript'>alert('Admin Record Not Updated');</script>";
	}
	?>
	


<head>
		<link rel="stylesheet" type="text/css" href="ast.css">
		<title>Admin</title>
	</head>
	<body>
		<header>
			<section>
				<h1>Northampton News</h1>
			</section>
		</header>
			<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
				
				
				
				

			</ul>
		</nav>
		<main>
				<nav>
				<ul>
				<li><a href="adminshow.php">Admin</a></li>
					<li><a href="adminCategories.php">Catagories</a></li>
					<li><a href="adminArticle.php"> News Article</a></li>
					<li><a href="comment.php">comments</a></li>
					<li><a href="adminregister.php">Register New Admin</a></li>
				    <li><a href="adminlogout.php">Log out</a></li>
				</ul>
			</nav>
			
				<form method="POST" action="admineditdelete.php">
				<input type="hidden" value="<?php echo $aid?>">
				<label>Full Name: </label>
				<input type="text" name="aname" value="<?php if(isset($run['fullname'])) echo $run['fullname'];?>"><br>
				<label>Email: </label>
				<input type="text" name="aemail" value="<?php if(isset($run['aemail'])) echo $run['aemail'];?>"><br>
			
				<input type="submit" name="reg" value="Update">
			</form>
	
			</main>
		
			</body>
			
			<footer>
			&copy; Northampton News 2017
		</footer>
		