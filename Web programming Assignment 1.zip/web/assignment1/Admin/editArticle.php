<?php
//sessionsstarting
session_start();
//passing the database
require 'dbconnection.php';
?>

<head>
		<link rel="stylesheet" type="text/css" href="ast.css">
		<title>Edit Article Page</title>
	</head>
	<body>
		<header>
			<section>
				<h1>Northampton News</h1>
			</section>
		</header>
			<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
			
			

			</ul>
		</nav>
			<main>
			
			<nav>
				<ul>
                    
				    <li><a href="addArticle.php">Add  Article</a></li>
					<li><a href="editArticle.php">Edit  Article</a></li>
                    <li><a href="deleteArticle.php">Delete  Article</a></li>
					
				</ul>
			</nav>
		
	
	
	<table  border="1">
	<thead>
		<tr>
			<th>SN</th>
			<th>Title</th>
			<th>Name</th>
			<th>News</th>
			<th>EDIT</th>
			
		</tr>
	</thead>
	<tbody>
	
			<tr>
			<?php
			//passsing the values
			$alsanstmt = $pdo->prepare("SELECT article_id, title,author,description FROM articles");
			//incremenent by one plus
			$a = 1;
			//passing the values
			$alsanstmt->execute();
			

			//loop
			foreach ($alsanstmt as $adrow) { ?>
				
				<td><?php echo $a++;?></td>
				<td><?php echo $adrow['title'];?></td>
				<td><?php echo $adrow['author'];?></td>
				<td><?php echo $adrow['description'];?></td>
				
				<form method="POST" action="editArticle.php">

				<input type="hidden" name="getadmin" value="">
				<td><input type="submit"  name="edit" value="Edit"></td>
				</form>
				
			</tr>
			
				<?php
			}	
			?>
				
			
			
			
		
	</tbody>
</table>
		
	
	
			</main>


	<footer>
			&copy; Northampton News 2017
		</footer>