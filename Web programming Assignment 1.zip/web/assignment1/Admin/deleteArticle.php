<?php
//starting the new sessions
session_start();
//dbconnection here
require 'dbconnection.php';

//when arid is pressed
if (isset($_GET['arid'])) {
	//getting arid
		$aid = $_GET['arid'];
		//select the data 
		$alsanstmt = $pdo->prepare("SELECT * FROM articles WHERE article_id = :arid");
		//passing the values
		$rcriteria = [
			'arid' => $arid
		];
		//running 
		$alsanstmt->execute($rcriteria);
		//fetching the data
		$run =$alsanstmt-> fetch();
	}
	?>
	<?php
	//when dlt button is pressed
if(isset($_POST['delete'])){
	//query using of delete
		$con = $pdo->prepare("DELETE FROM articles WHERE article_id = :gd");
		//unsetting the values
		unset($_POST['delete']);
		//running 
		$cresult= $con->execute($_POST);
		//using  if statemenets
		if($cresult==true)
		//message popup here
		echo "<script type='text/javascript'>alert('Article Deleted');</script>";
	
		else
		//popup messaage here
			echo "<script type='text/javascript'>alert('Article not Deleted ');</script>";
		}

?>

<head>
		<link rel="stylesheet" type="text/css" href="ast.css">
		<title>Delete Article Page</title>
	</head>
	<body>
		<header>
			<section>
				<h1>Northampton News</h1>
			</section>
		</header>
			<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
			
			

			</ul>
		</nav>
			<main>
			
			<nav>
				<ul>
                    
				    <li><a href="addArticle.php">Add  Article</a></li>
					<li><a href="editArticle.php">Edit  Article</a></li>
                    <li><a href="deleteArticle.php">Delete  Article</a></li>
					
				</ul>
			</nav>
		
	
	
	<table  border="1">
	<thead>
		<tr>
			<th>SN</th>
			<th>Title</th>
			<th>Name</th>
			<th>News</th>
			<th>Delete</th>
		</tr>
	</thead>
	<tbody>
	
			<tr>
			<?php
			//using and selecting the values
			$alsanstmt = $pdo->prepare("SELECT article_id, title,author,description FROM articles");
			//incremenets by 1
			$a = 1;
			//fetching the data
			$alsanstmt->execute();
			//using the loops to show the values
			foreach ($alsanstmt as $adrow) { ?>
				
				<td><?php echo $a++;?></td>
				<td><?php echo $adrow['title'];?></td>
				<td><?php echo $adrow['author'];?></td>
				<td><?php echo $adrow['description'];?></td>
				
				<form method="POST" action="deleteArticle.php">

				<input type="hidden" name="gd" value="<?php echo $adrow['article_id'];?>">
				<td><input type="submit"  name="delete" value="Delete"></td>
				</form>
				
			</tr>
			
				<?php
			}	
			?>
			
			
		
	</tbody>
</table>
		
	
	
			</main>


	<footer>
			&copy; Northampton News 2017
		</footer>