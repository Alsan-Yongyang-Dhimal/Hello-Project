<?php
$servername = "db";
$username = "root";
$password = "hello";


$pdo = new PDO("mysql:host=$servername; dbname=assignment1", $username, $password);

?>