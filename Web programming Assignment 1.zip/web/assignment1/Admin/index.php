

<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="st.css"/>
		<title>Admin-index-Page</title>
	
	</head>
	<body>
		<header>
			<section>
				<h1>Northampton News</h1>
			</section>
			
		</header>
		<nav>
			<ul>
			<li>
				<a href="index.php">Home</a></li>
				
				
				
				</li>
			</ul>
		</nav>
		<img src="images/banners/randombanner.php" />
		<main>
			
			<nav>
				<ul>
				<li>
				    <li><a href="adminshow.php">Admin</a></li>
					<li><a href="adminCategories.php">Catagories</a></li>
					<li><a href="adminArticle.php"> News Article</a></li>
					<li><a href="adminregister.php">Register New Admin</a></li>
				    <li><a href="adminlogout.php">Log out</a></li>
				   
				</ul>
			</nav>
			
			

			<h1>Welcome Admin </h1>
				
			
						
					<?php 
					
				?>	
				
					
						

							
			
				
				
			
		</main>

		<footer>
			&copy; Northampton News 2017
		</footer>

	</body>
</html>
