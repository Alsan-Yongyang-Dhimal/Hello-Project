<?php
session_start();
require 'dbconnection.php';


//sending the input inserting
if(isset($_POST['post'])){
	//using the pdo statement
$alsan = $pdo->prepare(" INSERT INTO articles( title, author, date, description )
		          VALUES( :atitle, :aauthor, :adate,:armessage )");
	
	$adcriteria = [
				
				'atitle'=> $_POST['atitle'],
				'aauthor'=>$_POST['aauthor'],
				'adate'=>date('Y-m-d H:i:s'),
                'armessage'=> $_POST['armessage']
		];
		//running 
		$alsan->execute($adcriteria);
	
}
?>

<head>
		<link rel="stylesheet" type="text/css" href="ast.css">
		<title>Add Article Page</title>
	</head>
	<body>
		<header>
			<section>
				<h1>Northampton News</h1>
			</section>
		</header>
			<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
               

			</ul>
		</nav>
			<main>
			
			<nav>
				<ul>
                  
                    <li><a href="addArticle.php">Add  Article</a></li>
					<li><a href="editArticle.php">Edit  Article</a></li>
                    <li><a href="deleteArticle.php">Delete  Article</a></li>
					
				</ul>
			</nav>
			<form method="POST" action="">
	<label>Title:</label>
	<input type="text" name="atitle"><br>
	<label>Name:</label>
	<input type="text" name="aauthor"><br>
		<label>Select Category</label>
		<select name="allcategory">

		<?php 
		//selecting the title 
			$ad = $pdo->query('SELECT title FROM categories');
			$ad->execute();
			foreach ($ad as $r) {
					echo '<option value="'.$r['category_id'].'">'.$r['title'].'</option>';
				}
               
		?>
	</select><br>
		
	
	<label>Description</label>
	<textarea rows="8" cols="80" name="armessage"></textarea><br>
	<input  type="submit" name="post" value="Post">
</form>
			</main>


	<footer>
			&copy; Northampton News 2017
		</footer>