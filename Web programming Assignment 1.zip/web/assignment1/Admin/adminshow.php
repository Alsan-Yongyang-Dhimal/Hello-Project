<?php
//starting the sess 
session_start();
//dbconnectioins
require 'dbconnection.php';


//when del button is pressed
if(isset($_POST['delete'])){
	//delete the values from admins table
$con = $pdo->prepare("DELETE FROM admins WHERE admin_id = :gd");
//unsetting the values
unset($_POST['delete']);
//passing the values
$cresult= $con->execute($_POST);
//if-condition
if($cresult==true)
//popup message say here below
echo "<script type='text/javascript'>alert('Admin Deleted Successfully');</script>";
else
//pop up message 
	echo "<script type='text/javascript'>alert('Admin Deleted ');</script>";
}

//when edit button is pressed
if(isset($_POST['edit'])){
	//declaring the variabale
	    $e = $_POST['edit'];
		//value passing
		$val = $_POST['gd'];
		//select  the values from the admins tables
		$rec = $pdo->query("SELECT * FROM admins WHERE admin_id= $val");
			//using the loop here 
			foreach($rec as $e =>$res){
				//pop up message here in the page
			echo '<a href="admineditdelete.php?aid='.$res['admin_id'].'">edit</a>';
		}

?>

<?php
}
?>


<head>
		<link rel="stylesheet" type="text/css" href="ast.css">
		<title>Show Admin Page</title>
	</head>
	<body>
		<header>
			<section>
				<h1>Northampton News</h1>
			</section>
		</header>
			<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
				
			</ul>
		</nav>
		<main>
			
			<nav>
				<ul>
				    <li><a href="adminshow.php">Admin</a></li>
					<li><a href="adminCategories.php">Catagories</a></li>
					<li><a href="adminArticle.php"> News Article</a></li>
					<li><a href="adminregister.php">Register New Admin</a></li>
				    <li><a href="adminlogout.php">Log out</a></li>
				   
				</ul>
			</nav>

	
<table  border="1">
	<thead>
		<tr>
			<th>SN</th>
			<th>Full name</th>
			<th>Email</th>
			<th>EDIT</th>
			<th>Delete</th>
		</tr>
	</thead>
	<tbody>
	<?php
	//passing the values in the table format
			$alsanstmt = $pdo->prepare("SELECT admin_id, fullname, email FROM admins");
			//increment the values by 1
			$n = 1;
			//running the values
			$alsanstmt->execute();
			
			//using the loop here
			foreach ($alsanstmt as $adrow) { ?>
			<tr>
				<td><?php echo $n++;?></td>
				<td><?php echo $adrow['fullname'];?></td>
				<td><?php echo $adrow['email'];?></td>
				<form method="POST" action="adminshow.php">

				<input type="hidden" name="gd" value="<?php echo $adrow['admin_id'];?>">
				<td><input type="submit"  name="edit" value="Edit"></td>
				<td><input type="submit"  name="delete" value="Delete"></td>
				</form>
				
			</tr>
			
				<?php	
					}
			?>
			
			
		
	</tbody>
</table>
			</main>

	<footer>
			&copy; Northampton News 2017
		</footer>