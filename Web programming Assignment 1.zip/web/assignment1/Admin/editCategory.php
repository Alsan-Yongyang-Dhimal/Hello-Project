<?php
//starting 
session_start();
//connecting
require 'dbconnection.php';
?>

<head>
		<link rel="stylesheet" type="text/css" href="ast.css">
		<title>Edit Category</title>
	</head>
	<body>
		<header>
			<section>
				<h1>Northampton News</h1>
			</section>
		</header>
			<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
			

			</ul>
		</nav>
			<main>
			
			<nav>
				<ul>
                    
                    <li><a href="addCategory.php">Add  Catagories</a></li>
					<li><a href="editCategory.php">Edit  Catagories</a></li>
                    <li><a href="deleteCategory.php">Delete  Catagories</a></li>
					
				</ul>
			</nav>
		
	
	
	<table id="table" border="1">
	<thead>
		<tr>
			<th>SN</th>
			<th>Title</th>
			<th>Edit</th>
		</tr>
	</thead>
	<tbody>
	
			<tr>
			<?php
			//getting from database
			$alsan = $pdo->prepare("SELECT category_id, title FROM categories");
			$a = 1;
			$alsan->execute();
			//loops here
			foreach ($alsan as $adrow) { ?>
				
				<td><?php echo $a++;?></td>
				<td><?php echo $adrow['title'];?></td>
				
			
			
				
				
				<form method="POST" action="editCategory.php">

				<input type="hidden" name="getadmin" value="<?php echo $adrow['category_id'];?>">
			
				<td><input type="submit"  name="edit" value="Edit" ></td>
				</form>
				
			</tr>
			
				<?php	
					}
			?>
				
				
			</tr>
			
				
			
		
	</tbody>
</table>
		
	
	
			</main>


	<footer>
			&copy; Northampton News 2017
		</footer>