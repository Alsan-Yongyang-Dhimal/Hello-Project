<?php
//starting the new session here
session_start();
//connecting the dbconnection here
require 'dbconnection.php';

//when logbutton is pressed
if(isset($_POST['log'])){
	   //it selects the admins values 
		$alsanstmt = $pdo->prepare("SELECT * FROM admins WHERE email =:aemail");
		//passing the values
		$alsancriteria = [
				'aemail' =>$_POST['aemail']
				
		];
		$res = false;
		//running the values
		$alsanstmt->execute($alsancriteria);
		//counting  the rowsvalues
		if($alsanstmt->rowCount() > 0){
			//fetching the data
			$u1 = $alsanstmt->fetch();
			//making password validation here
			if(password_verify($_POST['apassword'], $u1['password'])){
				//passing the adminid
			$_SESSION['admin_id'] = $u1['admin_id'];
			//passing the  heading location
			header('location:index.php');
			
		}
		else{
			$res = true;
		}
		
		}
		if($res == true){
			//pop up message comes like below
			echo "<script type='text/javascript'>alert('Please enter correct email and password');</script>";
		}
}
?>

<head>
		<link rel="stylesheet" href="style.css"/>
		<title>Admin Login Page</title>
	</head>
	<body>
		<header>
			<section>
				<h1>Northampton News</h1>
           </section>
</header>
		
		
<h2>Admin Login Here</h2>
<fieldset>
<form action="" method="POST">
<label class="Email">Email:</label>
<br>
<input type="text"  name="aemail" placeholder="  Email">
<br>
<label class="Pass">Password:</label>
<br>
<input type="password"  name="apassword" placeholder=" Password" >
<br>
<input type="submit" class="login-btn" name="log" value="Login">
<br>
<p>don't have an account?<a href="adminregister.php"> Register Now</a></p>
	
</form>
</fieldset>

		
	</body>

