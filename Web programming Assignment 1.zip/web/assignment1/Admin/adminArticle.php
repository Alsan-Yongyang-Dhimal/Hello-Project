<head>
		<link rel="stylesheet" type="text/css" href="ast.css">
		<title>Admin Article Page</title>
	</head>
	<body>
		<header>
			<section>
				<h1>Northampton News</h1>
			</section>
		</header>
			<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
			
			

			</ul>
		</nav>
			<main>
			
			<nav>
				<ul>
                    
				    <li><a href="addArticle.php">Add  Article</a></li>
					<li><a href="editArticle.php">Edit  Article</a></li>
                    <li><a href="deleteArticle.php">Delete  Article</a></li>
					
				</ul>
			</nav>
		<ul>
</ul>
	
	
		
	
	
			</main>


	<footer>
			&copy; Northampton News 2017
		</footer>