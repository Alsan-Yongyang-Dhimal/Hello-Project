<?php 
//dbconnection 
require 'dbconnection.php';
//when reg button is pressed
if(isset($_POST['adminreg'])){
	//inserts the values in database
		$va = $pdo->prepare ("INSERT INTO admins(fullname,email, password)
								VALUES(:aname,:aemail, :apassword)");
   //passing the parameters
		$cr =[
		'aname'=> $_POST['aname'],
		'aemail'=> $_POST['aemail'],
		//making the pw into hash
		'apassword' => password_hash($_POST['apassword'], PASSWORD_DEFAULT),
	
		];
		//running the code
		$va->execute($cr);
		//pop up message here using javascripts
		echo "<script type='text/javascript'>alert('Registered successfully');</script>";
	}

?>

<head>
		<link rel="stylesheet" type="text/css" href="astyle.css">
		<title>Register Admin Page</title>
	</head>
	<body>
		<header>
			<section>
				<h1>Northampton News</h1>
			</section>
		</header>
			
			
			<h2>Admin  Register Here</h2>
			<fieldset>
				<form method="POST" action="">
				<label>Full Name: </label>
				<input type="text" name="aname" required><br>
				<label>email: </label>
				<input type="text" name="aemail" required><br>
				<label>Password: </label>
				<input type="Password" name="apassword" required><br>
				<input type="submit" name="adminreg" value="Register">
                <br><br>
                <p> have an account?<a href="adminlogin.php"> login Now</a></p>
	
			</form>
           </fieldset>
	
			</main>
		
			</body>
			
			<footer>
			&copy; Northampton News 2017
		</footer>

