<?php
//starting the new sessions
session_start();
//connections the database
require 'dbconnection.php';

//when the button is pressed
if (isset($_GET['cat_id'])) {
	//getting the values
		$aid = $_GET['cat_id'];
		//selecting the data from dbcoonnections
		$alsanstmt = $pdo->prepare("SELECT * FROM categories WHERE category_id = :cat_id");
		//passing the values
		$rcriteria = [
			'cat_id' => $cat_id
		];
		//runnning
		$alsanstmt->execute($rcriteria);
		//running here
		$run = $$alsanstmt-> fetch();
	}
	?>
	<?php
	//deleting from the database
if(isset($_POST['delete'])){
	//selecting the values form dbconnections
		$con = $pdo->prepare("DELETE FROM categories WHERE category_id = :getadmin");
		//unsetting the values
		unset($_POST['delete']);
		//passing the  values
		$cresult= $con->execute($_POST);
		//if-statement using
		if($cresult==true)
		//pop up message says here
		echo "<script type='text/javascript'>alert('Category Deleted');</script>";
	
		else
		//pop up message says here
			echo "<script type='text/javascript'>alert('Category not Deleted ');</script>";
		}


?>





<head>
		<link rel="stylesheet" type="text/css" href="ast.css">
		<title>Delete Category Page</title>
	</head>
	<body>
		<header>
			<section>
				<h1>Northampton News</h1>
			</section>
		</header>
			<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
			

			</ul>
		</nav>
			<main>
			
			<nav>
				<ul>
                    
                    <li><a href="addCategory.php">Add  Catagories</a></li>
					<li><a href="editCategory.php">Edit  Catagories</a></li>
                    <li><a href="deleteCategory.php">Delete  Catagories</a></li>
					
				</ul>
			</nav>
		
	
	
	<table  border="1">
	<thead>
		<tr>
			<th>SN</th>
			<th>Title</th>
			<th>Delete</th>
		</tr>
	</thead>
	<tbody>
	
			<tr>
			<?php
			//passing the values and selecting 
			$alsanstmt = $pdo->prepare("SELECT category_id, title FROM categories");
			//increment by plus 1
			$a= 1;
			//running the code
			$alsanstmt->execute();
			//using llopps for all values
			foreach ($alsanstmt as $adrow) { ?>
				<td><?php echo $a++;?></td>
				<td><?php echo $adrow['title'];?></td>
				
									
				<form method="POST" action="deleteCategory.php">
				<input type="hidden" name="getadmin" value="<?php echo $adrow['category_id'];?>">
				<td><input type="submit"  name="delete" value="Delete"></td>
				</form>
				
			</tr>
			
				<?php	
					}
			?>
				
				
			</tr>
			
			
		
	</tbody>
</table>
		
	
	
			</main>


	<footer>
			&copy; Northampton News 2017
		</footer>