<?php
//session started
session_start();
//database connecting 
require 'dbconnection.php';
//when add button is pressed
if(isset($_POST['add'])){
	//inserting the data 
$adstmt = $pdo->prepare("INSERT INTO categories( title )
		   VALUES(:atitle )");
	        $ad = [
				//passing the value
				'atitle'=> $_POST['atitle']
				
		];
		//running
		$adstmt->execute($ad);
		//alert message using javascript
		echo "<script type='text/javascript'>alert('New category Added');</script>";
		//
}
?>







<head>
		<link rel="stylesheet" type="text/css" href="ast.css">
		<title>Add Category Page</title>
	</head>
	<body>
		<header>
			<section>
				<h1>Northampton News</h1>
			</section>
		</header>
			<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
				
			

			</ul>
		</nav>
			<main>
			
			<nav>
				<ul>
                    
                    <li><a href="addCategory.php">Add  Catagories</a></li>
					<li><a href="editCategory.php">Edit  Catagories</a></li>
                    <li><a href="deleteCategory.php">Delete  Catagories</a></li>
					
				</ul>
			</nav>
		
				<form method="POST" action="">
				<input type="hidden"  value="">
				<label>Title: </label>
				<input type="text" name="atitle" value="<?php if(isset($r['title'])) echo $r['title'];?>"><br>
		    	<input type="submit" name="add" value="Add">
			</form>
		
	
	
			</main>


	<footer>
			&copy; Northampton News 2017
	</footer>