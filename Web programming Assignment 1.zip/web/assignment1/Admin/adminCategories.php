


<head>
		<link rel="stylesheet" type="text/css" href="ast.css">
		<title>Admin Category Page</title>
	</head>
	<body>
		<header>
			<section>
				<h1>Northampton News</h1>
			</section>
		</header>
			<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
		
			

			</ul>
		</nav>
			<main>
			
			<nav>
				<ul>
                    
                    <li><a href="addCategory.php">Add  Catagories</a></li>
					<li><a href="editCategory.php">Edit  Catagories</a></li>
                    <li><a href="deleteCategory.php">Delete  Catagories</a></li>
					
				</ul>
			</nav>
	<ul>
</ul>
	
		
	
	
			</main>


	<footer>
			&copy; Northampton News 2017
		</footer>