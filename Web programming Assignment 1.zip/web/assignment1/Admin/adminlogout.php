<?php
//starting the session properly
session_start();
//unsetting the session here
session_unset();
//this destroys the sessions 
session_destroy();
//heading file 
header('location:adminlogin.php');
?>