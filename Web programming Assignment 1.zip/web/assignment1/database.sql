-- Adminer 4.8.1 MySQL 8.0.30 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;



DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `admin_id` int NOT NULL AUTO_INCREMENT,
  `fullname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `admins` (`admin_id`, `fullname`, `email`, `password`) VALUES
(14,	'Alsan Dhimal',	'alsan@gmail.com',	'$2y$10$kApuK/2OZKMqg68S4DW5FuhqOg.LdHDK8x2xoODXOggMoEY6Q9Vva')
ON DUPLICATE KEY UPDATE `admin_id` = VALUES(`admin_id`), `fullname` = VALUES(`fullname`), `email` = VALUES(`email`), `password` = VALUES(`password`);

DROP TABLE IF EXISTS `articles`;
CREATE TABLE `articles` (
  `article_id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `date` timestamp NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `articles` (`article_id`, `title`, `author`, `date`, `description`) VALUES
(32,	'Education',	'alsan',	'2022-09-25 07:50:58',	'ffff'),
(34,	'Education',	'Alsan',	'2022-09-25 10:43:29',	'education is important')
ON DUPLICATE KEY UPDATE `article_id` = VALUES(`article_id`), `title` = VALUES(`title`), `author` = VALUES(`author`), `date` = VALUES(`date`), `description` = VALUES(`description`);

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `category_id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `categories` (`category_id`, `title`) VALUES
(33,	'Sports'),
(34,	'Education'),
(35,	'Politics'),
(37,	'love')
ON DUPLICATE KEY UPDATE `category_id` = VALUES(`category_id`), `title` = VALUES(`title`);

DROP TABLE IF EXISTS `register_forms`;
CREATE TABLE `register_forms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fullname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contactnumber` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `register_forms` (`id`, `fullname`, `email`, `contactnumber`, `password`) VALUES
(1,	'Alsan Dhimal',	'alsandhimal646@gmail.com',	'9804049289',	'$2y$10$UYkslQehAORlqNn9KSFerOBK1/nr1oNNf1qKv4M0Uc8d9c7AMqHSG')
ON DUPLICATE KEY UPDATE `id` = VALUES(`id`), `fullname` = VALUES(`fullname`), `email` = VALUES(`email`), `contactnumber` = VALUES(`contactnumber`), `password` = VALUES(`password`);

-- 2022-09-25 14:27:54
