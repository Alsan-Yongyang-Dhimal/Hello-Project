<?php 
session_start();
require 'Admin/dbconnection.php';

?>

<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="st.css"/>
		<title>Northampton News - Home</title>
		
	</head>
	<body>
		<header>
			<section>
				<h1>Northampton News</h1>
			</section>

			
		</header>
		<nav>
			<ul>
			     <li><a href="index.php">Home</a></li>
				 <li><a href="latest.php">Latest Articles</a></li>
				 <li><a href="register.php">Register/login user</a></li>
				 <li><a href="admin/adminregister.php">Admin Register</a></li>
				 <li><a href="">Select Category</a>
				 
				 
					<ul>
						<?php 
							$s = $pdo->query('SELECT category_id, title FROM categories');
							$s->execute();
							foreach ($s as $r) {
								?>
								<li>
								<?php
								echo '<a href="index.php?'.$r['category_id'].'">'.$r['title'].'</a>';
								?>
								</li>
								<?php
							}
						?>
					</ul>
				</li>
				
				
			
							
								</li>
								<?php
							// }
						?>
				</li>
			</ul>
		</nav>
		<img src="images/banners/randombanner.php" />
		<main>
			

		<article>
				<h2>WELCOME TO THE NORTHAMPTON NEWS</h2>
				<p>HEADLINES:</p>
				
			
				<?php
//getting ta values form database 
$adstmt =$pdo->query("SELECT * FROM articles LIMIT 10");
//running
$adstmt ->execute();
foreach ($adstmt as $a) {?>
	  <li>Title: <?php echo $a['title'] ?></li>
	  <li>Name: <?php echo $a['author'] ?></li>
      <li>Date: <?php echo $a['date'] ?></li>
	  <li>News: <?php echo $a['description'] ?></li>
	  <li>Category: <?php 
		$dhstmt = $pdo->query('SELECT title FROM categories ');
		$dhstmt->execute();
		foreach ($dhstmt as $d) {
			echo $d['title'];
		}
	
 	?>
	<?php
}
	?>
	
	
</li>
	
				
				</fieldset>
				</ul>
			
			</article>
			
		</main>

		<footer>
			&copy; Northampton News 2017
		</footer>

	</body>
</html>
